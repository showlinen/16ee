## Module <custom_receipts_for_pos>

#### 21.11.2022
#### Version 16.0.1.0.0
#### ADD
Initial Commit for POS Receipt Designs.


