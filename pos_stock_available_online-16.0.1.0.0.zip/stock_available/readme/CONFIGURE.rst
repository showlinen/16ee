By default, this module computes the stock available to promise as the virtual
stock.
To take advantage of the additional features, you must define on which information you
want to base the computation, by checking one or more boxes in the settings:
`Inventory` > `Configuration` > `Settings` > `Stock available to promise`.
In case of "Include the production potential", it is also possible to configure
which field of product to use to compute the production potential.
