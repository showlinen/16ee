## Module <pos_refund_password>

#### 30.12.2022
#### Version 16.0.1.0.0
#### ADD
- Initial commit for pos_refund_password odoo
#### 28.03.2023
#### Version 16.0.1.0.1
#### FIX
- Fixed the undeclared body 
