In POS settings tick Add Discount in Line.
