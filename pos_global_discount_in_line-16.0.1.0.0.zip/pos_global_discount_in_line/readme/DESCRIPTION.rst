Include POS order discount in line instead of adding discount product.
