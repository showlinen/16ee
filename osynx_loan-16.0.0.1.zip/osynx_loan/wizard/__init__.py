# -*- coding: utf-8 -*-

from . import loan_extend_wizard
from . import loan_report_wizard