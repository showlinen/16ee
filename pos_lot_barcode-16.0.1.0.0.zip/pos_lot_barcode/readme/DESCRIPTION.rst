This module extends the point of sale functionalities to allow scanning a lot/serial number
using a barcode reader instead of having to enter it manually.
