In the Point of Sale configuration, you should make sure you have a barcode rule of type 'Lot'
 defined in the Barcode Nomenclature.
