1. Go to *Inventory > Settings* and set the option *Track lots or serial
   numbers*
2. Chose a product that is stockable, go to its *Inventory*
   tab, and set *Tracking* to *By Lots*.
3. Go to its *Sales* tab and set it as *Available in the Point of Sale*.
4. Click on *Update Qty On Hand*, chose the same location configured in the
   POS you want the lot available in; write a quantity; unfold the *Lot/Serial
   Number* field and pick create one if none is available yet.
5. Create a new lot with the serial number of your choice.
