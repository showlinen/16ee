This module allows to pick between existing lots in POS frontend.
