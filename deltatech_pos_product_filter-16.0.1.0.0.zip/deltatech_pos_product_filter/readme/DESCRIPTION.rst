Features:
 - Searching pos order using product
